<template>
  <v-footer app>
    <span class="ml-2">&copy; 2018</span><span class="ml-1">[ Your company name here ]</span>
  </v-footer>
</template>

<script>
  export default {
    name: "Footer"
  }
</script>

<style scoped lang="less">

</style>
